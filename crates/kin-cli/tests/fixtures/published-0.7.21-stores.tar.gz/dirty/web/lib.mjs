export function triple(value) {
  return value * 3;
}

export function sextuple(value) {
  return triple(value) * 2;
}
