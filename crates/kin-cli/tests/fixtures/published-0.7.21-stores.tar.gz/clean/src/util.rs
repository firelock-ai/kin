pub fn helper(value: u32) -> u32 {
    value * 2
}

pub fn triple(value: u32) -> u32 {
    value * 3
}
