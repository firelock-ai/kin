mod util;

pub use util::helper;

pub fn entry(value: u32) -> u32 {
    helper(value) + 1
}
