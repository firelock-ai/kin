import { triple } from './lib.mjs';

export function main() {
  return triple(2);
}
