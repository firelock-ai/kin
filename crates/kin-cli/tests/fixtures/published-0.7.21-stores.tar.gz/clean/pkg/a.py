from pkg.b import (
    double,
)


def run(value):
    return double(value) + 1
