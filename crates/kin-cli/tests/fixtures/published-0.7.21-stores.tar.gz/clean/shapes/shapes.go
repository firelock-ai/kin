package shapes

type Base struct{}

func (b Base) Describe() string {
	return "base"
}

type Circle struct {
	Base
	Radius float64
}

func Use(c Circle) string {
	return c.Describe()
}
